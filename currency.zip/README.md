# Uzbek Currency Bot

A simple Telegram bot that shows exchange rates of any currency in Uzbek soum.

## Run locally
1. Install dependencies: `pip install -r requirements.txt`
2. Set environment variable: `BOT_TOKEN=your_token_here`
3. Run: `python main.py`
